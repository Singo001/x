(() => {
  // src/settings.js
  var DEFAULTS = Object.freeze({ enabled: true, language: "da", grammar: true, terms: [] });
  function normalizeTerm(term) {
    return term.trim().normalize("NFC").toLocaleLowerCase("da");
  }
  function cleanTerms(terms) {
    if (!Array.isArray(terms)) throw new Error("Ordlisten skal v\xE6re en liste med ord eller termer.");
    const result = /* @__PURE__ */ new Map();
    for (const raw of terms) {
      if (typeof raw !== "string") throw new Error("Alle termer skal v\xE6re tekst.");
      const term = raw.trim().normalize("NFC").replace(/\s+/g, " ");
      if (!term) continue;
      if (term.length > 100 || /[\u0000-\u001f\u007f]/u.test(term)) throw new Error("En term m\xE5 h\xF8jst indeholde 100 tegn og ingen kontroltegn.");
      result.set(normalizeTerm(term), term);
    }
    if (result.size > 1e4) throw new Error("Ordlisten m\xE5 h\xF8jst indeholde 10.000 termer.");
    return [...result.values()];
  }
  function replacementLabel(value) {
    return value === "" ? "Fjern mellemrum" : value.trim() || "\xC9t mellemrum";
  }
  async function readSettings() {
    const stored = await chrome.storage.local.get(DEFAULTS);
    return { enabled: stored.enabled !== false, language: stored.language === "en" ? "en" : "da", grammar: stored.grammar !== false, terms: cleanTerms(stored.terms) };
  }

  // src/editor.js
  var BLOCKS = /* @__PURE__ */ new Set(["DIV", "P", "LI", "BLOCKQUOTE", "H1", "H2", "H3", "PRE"]);
  function isEligibleEditor(node) {
    if (!(node instanceof HTMLElement) || node.closest("[data-ordklar-ignore]")) return false;
    if (node instanceof HTMLTextAreaElement) return !node.disabled && !node.readOnly;
    if (node instanceof HTMLInputElement) return ["text", "search"].includes(node.type) && !node.disabled && !node.readOnly;
    return node.isContentEditable && !node.closest('[contenteditable="false"]');
  }
  function findEditor(event) {
    if (event.composedPath().some((node) => node instanceof HTMLElement && node.closest("[data-ordklar-ignore]"))) return null;
    for (const node of event.composedPath()) {
      if (!(node instanceof HTMLElement)) continue;
      if (node instanceof HTMLTextAreaElement) return isEligibleEditor(node) ? node : null;
      if (node instanceof HTMLInputElement) {
        return isEligibleEditor(node) ? node : null;
      }
      if (node.closest('[contenteditable="false"]')) return null;
      if (node.isContentEditable) {
        let root2 = node;
        while (root2.parentElement?.isContentEditable) root2 = root2.parentElement;
        return root2;
      }
    }
    return null;
  }
  function snapshot(editor2) {
    if ("value" in editor2) return { text: editor2.value, parts: [] };
    const parts = [];
    let text = "";
    function append(value, node, virtual = false, readonly = false) {
      if (!value) return;
      parts.push({ node, start: text.length, end: text.length + value.length, virtual, readonly });
      text += value;
    }
    function walk(node, readonly = false) {
      if (node.nodeType === Node.TEXT_NODE) {
        append(node.data, node, false, readonly);
        return;
      }
      if (node.nodeType !== Node.ELEMENT_NODE) return;
      if (["SCRIPT", "STYLE"].includes(node.tagName) || node.hidden || node.getAttribute("aria-hidden") === "true") return;
      readonly ||= node.getAttribute("contenteditable") === "false";
      if (node.tagName === "BR") {
        append("\n", node, true, readonly);
        return;
      }
      const block = node !== editor2 && BLOCKS.has(node.tagName);
      if (block && text && !text.endsWith("\n")) append("\n", node, true, readonly);
      for (const child of node.childNodes) walk(child, readonly);
      if (block && text && !text.endsWith("\n")) append("\n", node, true, readonly);
    }
    walk(editor2);
    return { text, parts };
  }
  function rangeFor(data2, offset, length) {
    const end = offset + length;
    if (data2.parts.some((p) => p.readonly && p.start < end && p.end > offset)) return null;
    const first = data2.parts.find((p) => !p.virtual && offset >= p.start && offset < p.end);
    const last = data2.parts.find((p) => !p.virtual && end > p.start && end <= p.end);
    if (!first || !last) return null;
    const range = document.createRange();
    range.setStart(first.node, offset - first.start);
    range.setEnd(last.node, end - last.start);
    return range;
  }
  function replacementProblem(editor2, data2, match, replacement) {
    if (editor2 && "value" in editor2 && editor2.maxLength >= 0 && data2.text.length - match.length + replacement.length > editor2.maxLength) {
      return `Rettelsen overskrider feltets maksimale l\xE6ngde p\xE5 ${editor2.maxLength} tegn.`;
    }
    return null;
  }
  function replaceText(editor2, data2, match, replacement) {
    if (!editor2?.isConnected || !isEligibleEditor(editor2) || snapshot(editor2).text !== data2.text) return false;
    editor2.focus({ preventScroll: true });
    if ("value" in editor2) {
      const value = data2.text.slice(0, match.offset) + replacement + data2.text.slice(match.offset + match.length);
      if (replacementProblem(editor2, data2, match, replacement)) return false;
      const prototype = editor2 instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(prototype, "value").set.call(editor2, value);
      editor2.setSelectionRange(match.offset + replacement.length, match.offset + replacement.length);
      editor2.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, inputType: "insertReplacementText", data: replacement }));
      return true;
    }
    const range = rangeFor(data2, match.offset, match.length);
    if (!range) return false;
    const selection = editor2.getRootNode().getSelection?.() || document.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
    const changed = document.execCommand("insertText", false, replacement);
    return changed && snapshot(editor2).text === data2.text.slice(0, match.offset) + replacement + data2.text.slice(match.offset + match.length);
  }
  function mirrorFor(editor2, data2, container = document.documentElement) {
    const mirror = document.createElement("div");
    mirror.style.all = "initial";
    const style = getComputedStyle(editor2);
    const rect = editor2.getBoundingClientRect();
    for (const name of ["box-sizing", "font-family", "font-size", "font-weight", "font-style", "font-variant", "line-height", "letter-spacing", "word-spacing", "text-align", "text-indent", "text-transform", "direction", "tab-size", "padding-top", "padding-right", "padding-bottom", "padding-left", "border-top-width", "border-right-width", "border-bottom-width", "border-left-width"]) mirror.style.setProperty(name, style.getPropertyValue(name));
    Object.assign(mirror.style, { boxSizing: "border-box", position: "fixed", margin: "0", left: `${rect.left}px`, top: `${rect.top}px`, width: `${rect.width}px`, height: `${rect.height}px`, visibility: "hidden", pointerEvents: "none", overflow: "hidden", borderStyle: "solid", whiteSpace: editor2 instanceof HTMLInputElement || editor2.wrap === "off" ? "pre" : "pre-wrap", overflowWrap: "break-word" });
    const text = document.createTextNode(data2.text || " ");
    mirror.append(text);
    container.append(mirror);
    if (editor2 instanceof HTMLTextAreaElement) mirror.style.paddingRight = `${parseFloat(style.paddingRight) + Math.max(0, editor2.offsetWidth - editor2.clientWidth - parseFloat(style.borderLeftWidth) - parseFloat(style.borderRightWidth))}px`;
    mirror.scrollTop = editor2.scrollTop;
    mirror.scrollLeft = editor2.scrollLeft;
    if (editor2 instanceof HTMLInputElement) {
      const range = document.createRange();
      range.selectNode(text);
      const glyphs = range.getBoundingClientRect();
      const paddingTop = parseFloat(style.paddingTop), paddingBottom = parseFloat(style.paddingBottom);
      const borderTop = parseFloat(style.borderTopWidth), borderBottom = parseFloat(style.borderBottomWidth);
      const contentHeight = rect.height - borderTop - borderBottom - paddingTop - paddingBottom;
      const delta = rect.top + borderTop + paddingTop + (contentHeight - glyphs.height) / 2 - glyphs.top;
      mirror.style.paddingTop = `${Math.max(0, paddingTop + delta)}px`;
    }
    return { mirror, text };
  }

  // src/content.js
  var host = document.createElement("div");
  host.dataset.ordklar = "overlay";
  Object.assign(host.style, { position: "fixed", inset: "0", zIndex: "2147483647", pointerEvents: "none" });
  var root = host.attachShadow({ mode: "open" });
  var css = document.createElement("style");
  css.textContent = `
  :host { all: initial; color-scheme: light; }
  * { box-sizing: border-box; }
  .mark { position: fixed; border-bottom: 2px dotted #e15a61; pointer-events: none; }
  .mark.grammar { border-color: #8260da; }
  .tip { position: fixed; width: 290px; padding: 17px; border: 1px solid #e2e8e3; border-radius: 16px; box-shadow: 0 12px 45px #172c2424; background: #fff; color: #233b30; font: 13px/1.5 system-ui,sans-serif; pointer-events: auto; }
  .tip[hidden] { display: none; }
  .heading { display: flex; align-items: center; gap: 7px; color: #6b776e; font-size: 11px; font-weight: 600; letter-spacing: .07em; text-transform: uppercase; }
  .dot { width: 7px; height: 7px; border-radius: 50%; background: #e15a61; }
  .dot.grammar { background: #8260da; }
  .word { font-size: 17px; font-weight: 650; margin: 9px 0 4px; overflow-wrap: anywhere; }
  .message { color: #6b776e; margin: 0 0 12px; }
  .suggestions { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px; }
  button { font: inherit; cursor: pointer; border: 1px solid #dce8df; background: #eff6f0; color: #226440; border-radius: 8px; padding: 7px 10px; }
  button:hover { background: #dfeee2; }
  button:focus-visible { outline: 2px solid #326e4c; outline-offset: 2px; }
  .secondary { background: transparent; border: none; padding: 4px 0; text-align: left; color: #6b776e; }
  .footer { border-top: 1px solid #edf0ed; padding-top: 9px; display: flex; justify-content: space-between; gap: 8px; }
  .status { position: fixed; background: #fff; border: 1px solid #dbe4dd; border-radius: 20px; padding: 4px 9px; font: 11px system-ui,sans-serif; color: #55675a; pointer-events: none; box-shadow: 0 2px 8px #172c2410; }
`;
  var marks = document.createElement("div");
  var tip = document.createElement("div");
  tip.className = "tip";
  tip.hidden = true;
  tip.setAttribute("role", "dialog");
  tip.setAttribute("aria-label", "Ordklar rettelser");
  var status = document.createElement("div");
  status.className = "status";
  status.hidden = true;
  status.setAttribute("role", "status");
  root.append(css, marks, tip, status);
  document.documentElement.append(host);
  var settings = { enabled: true };
  var editor = null;
  var data = null;
  var matches = [];
  var hitboxes = [];
  var timer;
  var layoutFrame;
  var hideTimer;
  var revision = 0;
  var displayed = null;
  var composing = false;
  var lastResult = null;
  var ignored = /* @__PURE__ */ new Set();
  var resize = new ResizeObserver(() => scheduleLayout());
  var mutation = new MutationObserver((records) => {
    if (records.every((record) => record.type === "attributes" && ["class", "style"].includes(record.attributeName))) scheduleLayout();
    else scheduleCheck();
  });
  async function send(message) {
    const result = await chrome.runtime.sendMessage(message);
    if (!result?.ok) throw new Error(result?.error || "Ordklar kunne ikke svare. Genindl\xE6s siden.");
    return result;
  }
  function closeTip() {
    tip.hidden = true;
    displayed = null;
    clearTimeout(hideTimer);
    hideTimer = null;
  }
  function clearMarks() {
    marks.replaceChildren();
    hitboxes = [];
    closeTip();
  }
  function activate(next) {
    if (next === editor) return;
    revision++;
    clearTimeout(timer);
    mutation.disconnect();
    resize.disconnect();
    editor = next;
    matches = [];
    data = null;
    composing = false;
    ignored.clear();
    clearMarks();
    status.hidden = true;
    if (!next) return;
    resize.observe(next);
    const rich = !("value" in next);
    mutation.observe(next, { attributes: true, attributeFilter: ["type", "readonly", "disabled", "contenteditable", "data-ordklar-ignore", "hidden", "class", "style"], subtree: rich, childList: rich, characterData: rich });
    scheduleCheck(0);
  }
  function scheduleCheck(delay = 450) {
    revision++;
    clearTimeout(timer);
    matches = [];
    data = null;
    lastResult = null;
    clearMarks();
    status.hidden = true;
    if (editor && !isEligibleEditor(editor)) {
      activate(null);
      return;
    }
    if (!settings.enabled || !editor?.isConnected || composing) return;
    timer = setTimeout(check, delay);
  }
  async function check() {
    if (!editor?.isConnected || !isEligibleEditor(editor) || !settings.enabled || composing) return;
    const current = revision, target = editor;
    const next = snapshot(target);
    if (!next.text.trim()) {
      matches = [];
      data = next;
      status.hidden = true;
      return;
    }
    status.textContent = "Kontrollerer\u2026";
    status.hidden = false;
    placeStatus();
    try {
      const result = await send({ type: "CHECK", text: next.text });
      if (current !== revision || editor !== target || snapshot(target).text !== next.text) return;
      data = next;
      matches = result.matches.filter((match) => !ignored.has(`${match.rule}:${next.text.slice(match.offset, match.offset + match.length)}`));
      lastResult = result;
      updateStatus();
      status.hidden = false;
      layout();
    } catch (error) {
      if (current !== revision) return;
      status.textContent = "Ordklar: genindl\xE6s siden";
      status.title = error.message;
      status.hidden = false;
      placeStatus();
    }
  }
  function updateStatus() {
    if (!lastResult) return;
    status.textContent = lastResult.truncated ? "Kun de f\xF8rste 12.000 tegn" : matches.length ? `${matches.length} forslag \xB7 ${lastResult.language === "da" ? "DA" : "EN"}` : "\u2713 Ingen forslag";
  }
  function placeStatus() {
    if (!editor?.isConnected) {
      status.hidden = true;
      return;
    }
    const rect = editor.getBoundingClientRect();
    if (!rect.width || !rect.height || rect.bottom < 0 || rect.top > innerHeight) {
      status.hidden = true;
      return;
    }
    if (data && settings.enabled && !composing && isEligibleEditor(editor)) status.hidden = false;
    status.style.left = `${Math.max(8, Math.min(innerWidth - 185, rect.right - 170))}px`;
    status.style.top = `${Math.max(4, Math.min(innerHeight - 27, rect.bottom + 5))}px`;
  }
  function scheduleLayout() {
    if (layoutFrame) return;
    layoutFrame = requestAnimationFrame(() => {
      layoutFrame = null;
      layout();
    });
  }
  function layout() {
    marks.replaceChildren();
    hitboxes = [];
    if (!editor?.isConnected) {
      activate(null);
      return;
    }
    placeStatus();
    if (!data || !settings.enabled || composing || !isEligibleEditor(editor) || data.text !== snapshot(editor).text) return;
    const bounds = editor.getBoundingClientRect();
    if (bounds.width === 0 || bounds.height === 0) {
      closeTip();
      return;
    }
    const mirror = "value" in editor ? mirrorFor(editor, data, root) : null;
    try {
      for (const match of matches) {
        let range;
        if (mirror) {
          range = document.createRange();
          range.setStart(mirror.text, match.offset);
          range.setEnd(mirror.text, match.offset + match.length);
        } else range = rangeFor(data, match.offset, match.length);
        if (!range) continue;
        for (const rect of range.getClientRects()) {
          const left = Math.max(rect.left, bounds.left, 0), right = Math.min(rect.right, bounds.right, innerWidth);
          const top = Math.max(rect.top, bounds.top, 0), bottom = Math.min(rect.bottom, bounds.bottom, innerHeight);
          if (right - left < 1 || bottom - top < 3) continue;
          const mark = document.createElement("div");
          mark.className = `mark ${match.kind}`;
          mark.dataset.word = data.text.slice(match.offset, match.offset + match.length);
          Object.assign(mark.style, { left: `${left}px`, top: `${bottom - 2}px`, width: `${right - left}px`, height: "2px" });
          marks.append(mark);
          hitboxes.push({ left, right, top, bottom, match });
        }
      }
    } finally {
      mirror?.mirror.remove();
    }
    if (displayed) {
      const box = hitboxes.find((h) => h.match === displayed);
      if (box) positionTip(box);
      else closeTip();
    }
  }
  function positionTip(box) {
    const width = Math.min(290, innerWidth - 16);
    tip.style.width = `${width}px`;
    tip.style.left = `${Math.max(8, Math.min(innerWidth - width - 8, box.left))}px`;
    const height = tip.getBoundingClientRect().height;
    const below = box.bottom + 9;
    tip.style.top = `${Math.max(8, below + height < innerHeight ? below : box.top - height - 9)}px`;
  }
  function button(label, action, className = "") {
    const element = document.createElement("button");
    element.type = "button";
    element.textContent = label;
    element.className = className;
    element.addEventListener("mousedown", (event) => event.preventDefault());
    element.addEventListener("click", action);
    return element;
  }
  async function showTip(box) {
    clearTimeout(hideTimer);
    hideTimer = null;
    if (displayed === box.match) return;
    const match = box.match, current = revision, currentData = data;
    displayed = match;
    tip.replaceChildren();
    const heading = document.createElement("div");
    heading.className = "heading";
    const dot = document.createElement("span");
    dot.className = `dot ${match.kind}`;
    heading.append(dot, match.kind === "spelling" ? "Ordklar \xB7 stavning" : "Ordklar \xB7 grammatik");
    const word = document.createElement("div");
    word.className = "word";
    word.textContent = currentData.text.slice(match.offset, match.offset + match.length);
    const message = document.createElement("p");
    message.className = "message";
    message.textContent = match.message;
    const suggestions = document.createElement("div");
    suggestions.className = "suggestions";
    const footer = document.createElement("div");
    footer.className = "footer";
    footer.append(button("Ignorer her", () => {
      ignored.add(`${match.rule}:${word.textContent}`);
      matches = matches.filter((item) => !(item.rule === match.rule && currentData.text.slice(item.offset, item.offset + item.length) === word.textContent));
      closeTip();
      updateStatus();
      layout();
    }, "secondary"));
    if (match.kind === "spelling") footer.append(button("+ Gem i ordliste", async () => {
      try {
        await send({ type: "ADD_TERMS", terms: [word.textContent] });
        closeTip();
        scheduleCheck(0);
      } catch (error) {
        message.textContent = error.message;
      }
    }, "secondary"));
    tip.append(heading, word, message, suggestions, footer);
    tip.hidden = false;
    function render(replacements) {
      if (displayed !== match || current !== revision) return;
      suggestions.replaceChildren();
      for (const replacement of replacements) suggestions.append(button(replacementLabel(replacement), () => {
        const problem = replacementProblem(editor, currentData, match, replacement);
        if (problem) {
          message.textContent = problem;
          positionTip(box);
          return;
        }
        if (replaceText(editor, currentData, match, replacement)) {
          closeTip();
          scheduleCheck(100);
        } else {
          message.textContent = "Teksten blev \xE6ndret. Kontrollerer igen\u2026";
          scheduleCheck(0);
        }
      }));
      if (!replacements.length) suggestions.textContent = "Ingen sikre staveforslag. Du kan gemme ordet.";
      positionTip(box);
    }
    if (match.kind === "spelling") {
      suggestions.textContent = "Finder forslag\u2026";
      positionTip(box);
      try {
        const result = await send({ type: "SUGGEST", word: match.word });
        render(result.replacements);
      } catch (error) {
        if (displayed === match) {
          suggestions.textContent = error.message;
          positionTip(box);
        }
      }
    } else render(match.replacements);
  }
  document.addEventListener("focusin", (event) => {
    if (event.composedPath().includes(host)) return;
    activate(findEditor(event));
  }, true);
  document.addEventListener("input", (event) => {
    const target = findEditor(event);
    if (target) {
      activate(target);
      scheduleCheck();
    } else if (event.composedPath().includes(editor)) activate(null);
  }, true);
  document.addEventListener("compositionstart", () => {
    composing = true;
    scheduleCheck();
  }, true);
  document.addEventListener("compositionend", () => {
    composing = false;
    scheduleCheck();
  }, true);
  document.addEventListener("pointermove", (event) => {
    if (event.composedPath().includes(host)) {
      clearTimeout(hideTimer);
      hideTimer = null;
      return;
    }
    const box = hitboxes.find((h) => event.clientX >= h.left && event.clientX <= h.right && event.clientY >= h.top - 2 && event.clientY <= h.bottom + 3);
    if (box) showTip(box);
    else if (!tip.hidden && !hideTimer) hideTimer = setTimeout(() => {
      hideTimer = null;
      closeTip();
    }, 260);
  }, true);
  tip.addEventListener("pointerenter", () => {
    clearTimeout(hideTimer);
    hideTimer = null;
  });
  tip.addEventListener("pointerleave", () => {
    hideTimer = setTimeout(() => {
      hideTimer = null;
      closeTip();
    }, 260);
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeTip();
    if (event.altKey && event.shiftKey && event.code === "KeyO" && hitboxes.length) {
      event.preventDefault();
      showTip(hitboxes[0]).then(() => tip.querySelector("button")?.focus());
    }
  }, true);
  document.addEventListener("scroll", () => {
    closeTip();
    scheduleLayout();
  }, true);
  window.addEventListener("resize", () => {
    closeTip();
    scheduleLayout();
  });
  chrome.storage.onChanged.addListener(async (_changes, area) => {
    if (area !== "local") return;
    settings = await readSettings();
    ignored.clear();
    scheduleCheck(0);
  });
  readSettings().then((value) => {
    settings = value;
    scheduleCheck(0);
  });
  if (document.activeElement instanceof HTMLElement) activate(findEditor({ composedPath: () => [document.activeElement] }));
})();
