(() => {
  // src/settings.js
  var DEFAULTS = Object.freeze({ enabled: true, language: "da", grammar: true, terms: [] });
  function normalizeTerm(term) {
    return term.trim().normalize("NFC").toLocaleLowerCase("da");
  }
  function cleanTerms(terms) {
    if (!Array.isArray(terms)) throw new Error("Ordlisten skal v\xE6re en liste med ord eller termer.");
    const result = /* @__PURE__ */ new Map();
    for (const raw of terms) {
      if (typeof raw !== "string") throw new Error("Alle termer skal v\xE6re tekst.");
      const term = raw.trim().normalize("NFC").replace(/\s+/g, " ");
      if (!term) continue;
      if (term.length > 100 || /[\u0000-\u001f\u007f]/u.test(term)) throw new Error("En term m\xE5 h\xF8jst indeholde 100 tegn og ingen kontroltegn.");
      result.set(normalizeTerm(term), term);
    }
    if (result.size > 1e4) throw new Error("Ordlisten m\xE5 h\xF8jst indeholde 10.000 termer.");
    return [...result.values()];
  }
  async function readSettings() {
    const stored = await chrome.storage.local.get(DEFAULTS);
    return { enabled: stored.enabled !== false, language: stored.language === "en" ? "en" : "da", grammar: stored.grammar !== false, terms: cleanTerms(stored.terms) };
  }

  // src/popup.js
  var enabled = document.querySelector("#enabled");
  var grammar = document.querySelector("#grammar");
  var feedback = document.querySelector("#feedback");
  function render(settings) {
    enabled.checked = settings.enabled;
    grammar.checked = settings.grammar;
    document.querySelector("#enabled-label").textContent = settings.enabled ? "Aktiv i dine tekstfelter" : "Korrektur er sat p\xE5 pause";
    for (const button of document.querySelectorAll("[data-language]")) button.setAttribute("aria-pressed", String(button.dataset.language === settings.language));
    document.querySelector("#term-count").textContent = settings.terms.length ? `${settings.terms.length} gemte termer \xB7 administrer og importer` : "Egne ord, fagudtryk og kryptotermer";
  }
  async function save(update) {
    try {
      await chrome.storage.local.set(update);
      render(await readSettings());
      feedback.className = "feedback";
      feedback.textContent = "Gemt. G\xE6lder ogs\xE5 i \xE5bne tekstfelter.";
    } catch {
      feedback.className = "feedback error";
      feedback.textContent = "Kunne ikke gemme. Pr\xF8v igen.";
    }
  }
  enabled.addEventListener("change", () => save({ enabled: enabled.checked }));
  grammar.addEventListener("change", () => save({ grammar: grammar.checked }));
  for (const button of document.querySelectorAll("[data-language]")) button.addEventListener("click", () => save({ language: button.dataset.language }));
  document.querySelector("#options").addEventListener("click", () => chrome.runtime.openOptionsPage());
  readSettings().then(render).catch(() => {
    feedback.textContent = "Indstillingerne kunne ikke indl\xE6ses.";
  });
})();
